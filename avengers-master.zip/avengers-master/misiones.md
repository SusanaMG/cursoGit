# Misiones

* Investigar al Dr. Doom
* Capturar a Red Skull
